package dictionaryPackage;

public class Word {
	private String wordName;
	private String wordDefinition;
	private String wordSentence;
   
   public Word(String wordName, String wordDefinition, String wordSentence){
      //set all the variable
	   this.wordName = wordName;
	   this.wordDefinition = wordDefinition;
	   this.wordSentence = wordSentence;
   }
   

public String getWordName() {
	return wordName;
}

public void setWordName(String wordName) {
	this.wordName = wordName;
}

public String getWordDefinition() {
	return wordDefinition;
}

public void setWordDefinition(String wordDefinition) {
	this.wordDefinition = wordDefinition;
}

public String getWordSentence() {
	return wordSentence;
}

public void setWordSentence(String wordSentence) {
	this.wordSentence = wordSentence;
}
   
}
